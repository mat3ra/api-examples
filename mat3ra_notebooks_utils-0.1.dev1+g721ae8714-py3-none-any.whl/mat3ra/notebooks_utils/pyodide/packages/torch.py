"""
Patches for PyTorch and related packages to work in Pyodide environment.

This module provides shared Pyodide compatibility patches for torch-based MLFF
packages. Package-specific patches live in their corresponding package modules.

Usage:
    from mat3ra.notebooks_utils.pyodide.packages.patches import apply_all_patches

    apply_all_patches("mace")
"""

import sys
import types
from collections import namedtuple

import numpy as np
import torch

# Define return types to mimic PyTorch's named tuples
EigRet = namedtuple("linalg_eig", ["eigenvalues", "eigenvectors"])  # type: ignore
EighRet = namedtuple("linalg_eigh", ["eigenvalues", "eigenvectors"])  # type: ignore
LUFactorReturn = namedtuple("LUFactorReturn", ["LU", "pivots"])
_OMEGACONF_RESOLVERS = {}


class _DictConfig(dict):
    pass


class _ListConfig(list):
    pass


class _OmegaConf:
    @staticmethod
    def to_container(cfg, **kwargs):
        return dict(cfg) if isinstance(cfg, dict) else cfg

    @staticmethod
    def create(data):
        return _DictConfig(data) if isinstance(data, dict) else data

    @staticmethod
    def register_new_resolver(name, func, **kwargs):
        _OMEGACONF_RESOLVERS[name] = func

    @staticmethod
    def register_resolver(name, func, **kwargs):
        _OMEGACONF_RESOLVERS[name] = func

    @staticmethod
    def has_resolver(name):
        return name in _OMEGACONF_RESOLVERS


def _ensure_omegaconf_stub():
    omegaconf_mod = sys.modules.get("omegaconf") or _make_stub_module("omegaconf")
    omegaconf_mod.DictConfig = getattr(omegaconf_mod, "DictConfig", _DictConfig)
    omegaconf_mod.ListConfig = getattr(omegaconf_mod, "ListConfig", _ListConfig)
    omega_conf = getattr(omegaconf_mod, "OmegaConf", _OmegaConf)
    for name in ("register_new_resolver", "register_resolver", "has_resolver"):
        if not hasattr(omega_conf, name):
            setattr(omega_conf, name, getattr(_OmegaConf, name))
    omegaconf_mod.OmegaConf = omega_conf
    return omegaconf_mod


def _to_np(tensor):
    return tensor.detach().cpu().numpy()


def _to_torch(array, device, dtype=None):
    if dtype:
        return torch.tensor(array, device=device, dtype=dtype)
    return torch.tensor(array, device=device)


# ==============================================================================
# Torch linalg patches
# ==============================================================================


def _patch_solve(A, B, *args, **kwargs):
    return _to_torch(np.linalg.solve(_to_np(A), _to_np(B)), A.device)


def _patch_inv(A, *args, **kwargs):
    return _to_torch(np.linalg.inv(_to_np(A)), A.device)


def _patch_det(A, *args, **kwargs):
    return _to_torch(np.linalg.det(_to_np(A)), A.device)


def _patch_cholesky(A, *args, **kwargs):
    return _to_torch(np.linalg.cholesky(_to_np(A)), A.device)


def _patch_eig(A, *args, **kwargs):
    vals, vecs = np.linalg.eig(_to_np(A))
    return EigRet(_to_torch(vals, A.device), _to_torch(vecs, A.device))


def _patch_eigh(A, UPLO="L", *args, **kwargs):
    vals, vecs = np.linalg.eigh(_to_np(A), UPLO=UPLO)
    return EighRet(_to_torch(vals, A.device), _to_torch(vecs, A.device))


def _patch_lu_factor(A, *args, **kwargs):
    import scipy.linalg

    A_np = _to_np(A)
    if A_np.ndim > 2:
        orig_shape = A_np.shape
        A_reshaped = A_np.reshape(-1, orig_shape[-2], orig_shape[-1])
        lu_list, piv_list = [], []
        for mat in A_reshaped:
            lu, piv = scipy.linalg.lu_factor(mat)
            lu_list.append(lu)
            piv_list.append(piv)
        LU_np = np.stack(lu_list).reshape(orig_shape)
        piv_np = np.stack(piv_list).reshape(orig_shape[:-2] + (-1,))
    else:
        LU_np, piv_np = scipy.linalg.lu_factor(A_np)
    return LUFactorReturn(_to_torch(LU_np, A.device, A.dtype), _to_torch(piv_np, A.device, torch.int32))


def _patch_lu_solve(LU, pivots, B, *args, **kwargs):
    import scipy.linalg

    LU_np, piv_np, B_np = _to_np(LU), _to_np(pivots), _to_np(B)
    if LU_np.ndim > 2:
        orig_shape_B = B_np.shape
        LU_reshaped = LU_np.reshape(-1, LU_np.shape[-2], LU_np.shape[-1])
        piv_reshaped = piv_np.reshape(-1, piv_np.shape[-1])
        is_vector = B_np.ndim == LU_np.ndim - 1
        B_reshaped = (
            B_np.reshape(-1, B_np.shape[-1], 1) if is_vector else B_np.reshape(-1, B_np.shape[-2], B_np.shape[-1])
        )
        X_list = [scipy.linalg.lu_solve((lu, piv), b) for lu, piv, b in zip(LU_reshaped, piv_reshaped, B_reshaped)]
        X_np = np.stack(X_list).reshape(orig_shape_B)
    else:
        X_np = scipy.linalg.lu_solve((LU_np, piv_np), B_np)
    return _to_torch(X_np, B.device, B.dtype)


def _tensor_array_compat(self, dtype=None):
    """Replacement for Tensor.__array__ in Pyodide where tensor.numpy() is unavailable."""
    arr = np.array(self.tolist())
    return arr.astype(dtype) if dtype is not None else arr


def patch_torch_linalg():
    """
    Patch torch.linalg functions to use NumPy/SciPy implementations.

    This fixes LAPACK functions that are not available in Pyodide's WASM torch build.
    """
    torch.linalg.solve = _patch_solve
    torch.linalg.inv = _patch_inv
    torch.inverse = _patch_inv  # Alias
    torch.linalg.det = _patch_det
    torch.det = _patch_det  # Alias
    torch.linalg.cholesky = _patch_cholesky
    torch.linalg.eig = _patch_eig
    torch.linalg.eigh = _patch_eigh
    torch.linalg.lu_factor = _patch_lu_factor
    torch.linalg.lu_solve = _patch_lu_solve

    # Fix numpy compatibility
    torch.Tensor.__array__ = _tensor_array_compat
    torch.Tensor.numpy = lambda self: np.array(self.detach().tolist())

    # torch.from_numpy — WASM PyTorch build lacks NumPy interop
    _orig_from_numpy = torch.from_numpy

    def _patched_from_numpy(ndarray):
        try:
            return _orig_from_numpy(ndarray)
        except RuntimeError:
            return torch.tensor(ndarray.tolist())

    torch.from_numpy = _patched_from_numpy

    # torch.as_tensor — also uses numpy interop internally
    _orig_as_tensor = torch.as_tensor

    def _patched_as_tensor(data, dtype=None, device=None):
        try:
            return _orig_as_tensor(data, dtype=dtype, device=device)
        except (RuntimeError, TypeError):
            if hasattr(data, "tolist"):
                return torch.tensor(data.tolist(), dtype=dtype, device=device)
            return torch.tensor(data, dtype=dtype, device=device)

    torch.as_tensor = _patched_as_tensor

    # Tensor indexing — WASM PyTorch can't infer numpy dtypes for boolean/integer masks
    _orig_getitem = torch.Tensor.__getitem__

    def _patched_getitem(self, key):
        if isinstance(key, np.ndarray):
            key = torch.tensor(key.tolist())
        return _orig_getitem(self, key)

    torch.Tensor.__getitem__ = _patched_getitem

    _orig_setitem = torch.Tensor.__setitem__

    def _patched_setitem(self, key, value):
        if isinstance(key, np.ndarray):
            key = torch.tensor(key.tolist())
        return _orig_setitem(self, key, value)

    torch.Tensor.__setitem__ = _patched_setitem

    # torch.tensor — handle lists of 0-d tensors (WASM calls len() on elements, fails for 0-d)
    _orig_torch_tensor = torch.tensor

    def _patched_torch_tensor(data, *args, **kwargs):
        if isinstance(data, (list, tuple)):

            def _unwrap(item):
                if isinstance(item, torch.Tensor) and item.ndim == 0:
                    return item.item()
                return item

            data = type(data)(_unwrap(x) for x in data)
        return _orig_torch_tensor(data, *args, **kwargs)

    torch.tensor = _patched_torch_tensor

    print("✓ Torch linalg + numpy interop patches applied")


# ==============================================================================
# Torch testing patches
# ==============================================================================


class _LoggingTensorModeStub:
    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


def _capture_logs_stub(*args, **kwargs):
    return _LoggingTensorModeStub()


def patch_torch_testing():
    """
    Stub torch.testing._internal modules that are missing in Pyodide.

    These modules are used by MACE imports but not needed for inference.
    """
    _internal = types.ModuleType("torch.testing._internal")
    _internal.__path__ = []
    _internal.__package__ = "torch.testing._internal"

    _common_utils = types.ModuleType("torch.testing._internal.common_utils")
    _common_utils.dtype_abbrs = {}

    _logging_tensor = types.ModuleType("torch.testing._internal.logging_tensor")
    _logging_tensor.LoggingTensorMode = _LoggingTensorModeStub
    _logging_tensor.capture_logs = _capture_logs_stub

    _internal.common_utils = _common_utils
    _internal.logging_tensor = _logging_tensor
    sys.modules["torch.testing._internal"] = _internal
    sys.modules["torch.testing._internal.common_utils"] = _common_utils
    sys.modules["torch.testing._internal.logging_tensor"] = _logging_tensor

    # Import torch.utils.checkpoint AFTER logging_tensor stubs are set up
    # (checkpoint.py imports logging_tensor at import time)
    import torch.utils.checkpoint  # noqa: F401

    print("✓ Torch testing patches applied")


# ==============================================================================
# Torch compiler patches
# ==============================================================================


def patch_torch_compiler():
    """
    Patch torch.compiler for Pyodide WASM.

    - Stubs torch.compiler.is_compiling (not available in WASM build)
    - Makes torch.compiler.disable a no-op decorator (avoids torch._dynamo
      import chain which requires C extensions missing in WASM)
    - Needed by e3nn >= 0.5 and fairchem-core which use @torch.compiler.disable
    """
    if not hasattr(torch, "compiler"):
        torch.compiler = types.ModuleType("torch.compiler")
    if not hasattr(torch.compiler, "is_compiling"):
        torch.compiler.is_compiling = lambda: False

    def _compiler_disable(fn=None, recursive=True):
        if fn is not None:
            return fn
        return lambda f: f

    torch.compiler.disable = _compiler_disable

    print("✓ Torch compiler patches applied")


# ==============================================================================
# Torch distributed patches (for FAIRChem)
# ==============================================================================


def patch_torch_distributed():
    """
    Stub torch.distributed modules that require C extensions missing in WASM.

    FAIRChem's mlip_unit.py imports from torch.distributed.checkpoint,
    torch.distributed.fsdp, and torch.distributed.device_mesh.
    All of these trigger torch._C._distributed_c10d which doesn't exist in WASM.
    """
    import enum

    import torch.distributed as _dist

    # Core distributed API stubs
    if not hasattr(_dist, "group"):

        class _Group:
            WORLD = None

        _dist.group = _Group
        _dist.WORLD = None
    if not hasattr(_dist, "ReduceOp"):

        class _ReduceOp:
            SUM = 0
            PRODUCT = 1
            MIN = 2
            MAX = 3
            BAND = 4
            BOR = 5
            BXOR = 6
            AVG = 7

        _dist.ReduceOp = _ReduceOp
    if not hasattr(_dist, "is_initialized"):
        _dist.is_initialized = lambda: False
    if not hasattr(_dist, "get_rank"):
        _dist.get_rank = lambda group=None: 0
    if not hasattr(_dist, "get_world_size"):
        _dist.get_world_size = lambda group=None: 1

    # torch.distributed.nn.functional
    _dist_nn = types.ModuleType("torch.distributed.nn")
    _dist_nn.__path__ = []
    _dist_nn.__package__ = "torch.distributed.nn"
    _dist_nn_func = types.ModuleType("torch.distributed.nn.functional")
    _dist_nn_func.__package__ = "torch.distributed.nn"
    _dist_nn_func.all_reduce = lambda tensor, *a, **k: tensor
    _dist_nn_func.reduce_scatter = lambda output, input_list, *a, **k: output
    _dist_nn_func.all_gather = lambda tensor_list, tensor, *a, **k: tensor_list
    _dist_nn.functional = _dist_nn_func
    sys.modules["torch.distributed.nn"] = _dist_nn
    sys.modules["torch.distributed.nn.functional"] = _dist_nn_func

    # C extension stubs
    sys.modules["torch._C._distributed_c10d"] = types.ModuleType("torch._C._distributed_c10d")
    _dc10d = types.ModuleType("torch.distributed.distributed_c10d")
    _dc10d.__package__ = "torch.distributed"
    sys.modules["torch.distributed.distributed_c10d"] = _dc10d

    # torch.distributed._shard
    _shard = types.ModuleType("torch.distributed._shard")
    _shard.__path__ = []
    _shard.__package__ = "torch.distributed._shard"
    sys.modules["torch.distributed._shard"] = _shard
    sys.modules["torch.distributed._shard.api"] = types.ModuleType("torch.distributed._shard.api")
    _shard_st = types.ModuleType("torch.distributed._shard.sharded_tensor")
    _shard_st.__path__ = []
    sys.modules["torch.distributed._shard.sharded_tensor"] = _shard_st
    _shard_st_meta = types.ModuleType("torch.distributed._shard.sharded_tensor.metadata")

    class _TensorProperties:
        pass

    _shard_st_meta.TensorProperties = _TensorProperties
    sys.modules["torch.distributed._shard.sharded_tensor.metadata"] = _shard_st_meta

    # torch.distributed.checkpoint
    _dcp = types.ModuleType("torch.distributed.checkpoint")
    _dcp.__path__ = []
    _dcp.__package__ = "torch.distributed.checkpoint"
    _dcp.save = lambda *a, **k: None
    _dcp.load = lambda *a, **k: None
    _dcp_meta = types.ModuleType("torch.distributed.checkpoint.metadata")
    _dcp_meta.TensorProperties = _TensorProperties

    class _BytesStorageMetadata:
        pass

    class _TensorStorageMetadata:
        pass

    class _Metadata:
        pass

    _dcp_meta.BytesStorageMetadata = _BytesStorageMetadata
    _dcp_meta.TensorStorageMetadata = _TensorStorageMetadata
    _dcp_meta.Metadata = _Metadata
    _dcp.metadata = _dcp_meta
    sys.modules["torch.distributed.checkpoint"] = _dcp
    sys.modules["torch.distributed.checkpoint.metadata"] = _dcp_meta

    for sub in [
        "state_dict",
        "stateful",
        "planner",
        "storage",
        "default_planner",
        "filesystem",
        "optimizer",
        "format_utils",
    ]:
        _sub_mod = types.ModuleType(f"torch.distributed.checkpoint.{sub}")
        _sub_mod.__package__ = "torch.distributed.checkpoint"
        sys.modules[f"torch.distributed.checkpoint.{sub}"] = _sub_mod
        setattr(_dcp, sub, _sub_mod)

    # format_utils stubs
    sys.modules["torch.distributed.checkpoint.format_utils"].dcp_to_torch_save = lambda *a, **k: None
    sys.modules["torch.distributed.checkpoint.format_utils"].torch_save_to_dcp = lambda *a, **k: None

    # state_dict stubs
    _sd_mod = sys.modules["torch.distributed.checkpoint.state_dict"]
    _sd_mod.get_model_state_dict = lambda model, *a, **k: model.state_dict() if hasattr(model, "state_dict") else {}
    _sd_mod.set_model_state_dict = (
        lambda model, sd, *a, **k: model.load_state_dict(sd) if hasattr(model, "load_state_dict") else None
    )
    _sd_mod.get_optimizer_state_dict = (
        lambda model, optim, *a, **k: optim.state_dict() if hasattr(optim, "state_dict") else {}
    )
    _sd_mod.get_state_dict = lambda model, *a, **k: model.state_dict() if hasattr(model, "state_dict") else {}
    _sd_mod.set_state_dict = lambda model, sd, *a, **k: None

    class _StateDictOptions:
        def __init__(self, **k):
            self.__dict__.update(k)

    _sd_mod.StateDictOptions = _StateDictOptions

    # stateful stub
    class _Stateful:
        pass

    sys.modules["torch.distributed.checkpoint.stateful"].Stateful = _Stateful

    # torch.distributed.fsdp
    _fsdp = types.ModuleType("torch.distributed.fsdp")
    _fsdp.__path__ = []
    _fsdp.__package__ = "torch.distributed.fsdp"
    sys.modules["torch.distributed.fsdp"] = _fsdp
    for fsdp_sub in ["fully_sharded_data_parallel", "api", "wrap", "sharded_grad_scaler"]:
        _fsub = types.ModuleType(f"torch.distributed.fsdp.{fsdp_sub}")
        _fsub.__package__ = "torch.distributed.fsdp"
        sys.modules[f"torch.distributed.fsdp.{fsdp_sub}"] = _fsub
        setattr(_fsdp, fsdp_sub, _fsub)

    # FSDP wrap policy stubs
    class _ModuleWrapPolicy:
        def __init__(self, module_classes=None):
            self.module_classes = module_classes or set()

    _fsdp_wrap = sys.modules["torch.distributed.fsdp.wrap"]
    _fsdp_wrap.ModuleWrapPolicy = _ModuleWrapPolicy
    _fsdp_wrap.lambda_auto_wrap_policy = lambda *a, **k: None
    _fsdp_wrap.transformer_auto_wrap_policy = lambda *a, **k: None

    # FSDP classes
    class _FullyShardedDataParallel(torch.nn.Module):
        def __init__(self, module, *a, **k):
            super().__init__()
            self.module = module

    class _ShardingStrategy(enum.Enum):
        FULL_SHARD = "FULL_SHARD"
        SHARD_GRAD_OP = "SHARD_GRAD_OP"
        NO_SHARD = "NO_SHARD"
        HYBRID_SHARD = "HYBRID_SHARD"

    class _MixedPrecision:
        def __init__(self, *a, **k):
            pass

    class _CPUOffload:
        def __init__(self, offload_params=False):
            self.offload_params = offload_params

    class _BackwardPrefetch(enum.Enum):
        BACKWARD_PRE = "BACKWARD_PRE"
        BACKWARD_POST = "BACKWARD_POST"

    class _StateDictTypeFSDP(enum.Enum):
        FULL_STATE_DICT = 0
        LOCAL_STATE_DICT = 1
        SHARDED_STATE_DICT = 2

    _fsdp.FullyShardedDataParallel = _FullyShardedDataParallel
    _fsdp.ShardingStrategy = _ShardingStrategy
    _fsdp.MixedPrecision = _MixedPrecision
    _fsdp.CPUOffload = _CPUOffload
    _fsdp.BackwardPrefetch = _BackwardPrefetch
    _fsdp.StateDictType = _StateDictTypeFSDP

    # FSDP StateDictConfig stubs
    class _StateDictConfig:
        def __init__(self, **k):
            self.__dict__.update(k)

    class _ShardedStateDictConfig(_StateDictConfig):
        pass

    class _FullStateDictConfig(_StateDictConfig):
        def __init__(self, offload_to_cpu=False, rank0_only=False, **k):
            super().__init__(**k)
            self.offload_to_cpu = offload_to_cpu
            self.rank0_only = rank0_only

    class _FullOptimStateDictConfig(_StateDictConfig):
        def __init__(self, offload_to_cpu=False, rank0_only=False, **k):
            super().__init__(**k)

    _fsdp.StateDictConfig = _StateDictConfig
    _fsdp.ShardedStateDictConfig = _ShardedStateDictConfig
    _fsdp.FullStateDictConfig = _FullStateDictConfig
    _fsdp.FullOptimStateDictConfig = _FullOptimStateDictConfig
    _fsdp.LocalStateDictConfig = type("LocalStateDictConfig", (_StateDictConfig,), {})
    _fsdp.OptimStateDictConfig = type("OptimStateDictConfig", (_StateDictConfig,), {})
    _fsdp.ShardedOptimStateDictConfig = type("ShardedOptimStateDictConfig", (_StateDictConfig,), {})

    # torch.distributed.device_mesh
    _dm = types.ModuleType("torch.distributed.device_mesh")
    _dm.__package__ = "torch.distributed"

    class _DeviceMesh:
        def __init__(self, *a, **k):
            pass

    _dm.DeviceMesh = _DeviceMesh
    _dm.init_device_mesh = lambda *a, **k: _DeviceMesh()
    sys.modules["torch.distributed.device_mesh"] = _dm

    # torch.distributed.tensor (DTensor)
    _dtensor = types.ModuleType("torch.distributed.tensor")
    _dtensor.__path__ = []
    _dtensor.__package__ = "torch.distributed.tensor"

    class _DTensor:
        pass

    _dtensor.DTensor = _DTensor
    sys.modules["torch.distributed.tensor"] = _dtensor

    # torch.distributed.algorithms
    _dalgo = types.ModuleType("torch.distributed.algorithms")
    _dalgo.__path__ = []
    _dalgo.__package__ = "torch.distributed.algorithms"
    sys.modules["torch.distributed.algorithms"] = _dalgo

    print("✓ Torch distributed patches applied")


# ==============================================================================
# Stub helpers
# ==============================================================================


def _make_stub_module(name, attrs=None, submodules=None):
    """Create a stub module with optional attributes and submodules."""
    from importlib.machinery import ModuleSpec

    mod = types.ModuleType(name)
    mod.__path__ = []
    mod.__package__ = name
    mod.__version__ = "0.0.0"
    mod.__spec__ = ModuleSpec(name, None, is_package=True)
    if attrs:
        for k, v in attrs.items():
            setattr(mod, k, v)
    sys.modules[name] = mod
    if submodules:
        for sub_name in submodules:
            full_name = f"{name}.{sub_name}"
            sub_mod = types.ModuleType(full_name)
            sub_mod.__path__ = []
            sub_mod.__package__ = name
            sub_mod.__spec__ = ModuleSpec(full_name, None, is_package=True)
            setattr(mod, sub_name, sub_mod)
            sys.modules[full_name] = sub_mod
    return mod


# ==============================================================================
# Matscipy patches
# ==============================================================================


def _matscipy_neighbour_list_compat(quantities, atoms=None, cutoff=None, positions=None, cell=None, pbc=None, **_):
    """Translate matscipy-style keyword-arg call into an ASE neighbor_list call."""
    from ase import Atoms as _Atoms
    from ase.neighborlist import neighbor_list as _ase_neighbor_list

    if atoms is None:
        atoms = _Atoms(positions=positions, cell=cell, pbc=pbc if pbc is not None else [False, False, False])
    return _ase_neighbor_list(quantities, atoms, cutoff)


def patch_matscipy():
    """
    Stub matscipy package with ASE neighbor_list compatibility.

    Matscipy is a C-extension package that cannot be compiled for WASM.
    MACE uses it for neighbor calculations, which we redirect to ASE.
    """
    _matscipy = types.ModuleType("matscipy")
    _matscipy.__path__ = []
    _matscipy.__package__ = "matscipy"
    _matscipy_neighbours = types.ModuleType("matscipy.neighbours")
    _matscipy_neighbours.neighbour_list = _matscipy_neighbour_list_compat
    _matscipy.neighbours = _matscipy_neighbours
    sys.modules["matscipy"] = _matscipy
    sys.modules["matscipy.neighbours"] = _matscipy_neighbours

    print("✓ Matscipy patches applied")


def apply_common_torch_patches():
    """Apply shared Pyodide patches needed by torch-based MLFF packages."""
    patch_torch_linalg()
    patch_torch_compiler()
    patch_torch_testing()
    patch_matscipy()
